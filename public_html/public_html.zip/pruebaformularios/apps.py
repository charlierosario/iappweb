from django.apps import AppConfig


class PruebaformulariosConfig(AppConfig):
    name = 'pruebaformularios'
    verbose_name = 'Formulario de Inscripción'
